echo -n "message commit: "
read varmes
git add --all
git commit -am $varmes
git push origin master 
