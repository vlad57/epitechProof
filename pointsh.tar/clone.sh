echo -n "login : "
read varlogin
echo -n "repo : "
read varepo
git clone git@git.epitech.eu:/$varlogin/$varepo

