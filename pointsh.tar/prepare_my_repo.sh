echo -n "enter login: "
read varlog
echo -n "enter repo: "
read varepo
blih.py -u $varlog repository create $varepo
blih.py -u $varlog repository setacl $varepo ramassage-tek r
blih.py -u $varlog repository  getacl $varepo
